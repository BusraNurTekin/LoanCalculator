package com.example.loancalculatorapp;
import androidx.appcompat.app.AppCompatActivity;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

public class LoanCalculatorApp extends AppCompatActivity {
    EditText monthlyPayment;
    EditText totalPayment;
    double interestRate,loanAmount;
    double monthlyPaymentValue,totalPaymentValue;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        EditText interestRateGirdi = (EditText) findViewById(R.id.interestRateGirdi);
        EditText loanAmountGirdi = (EditText) findViewById(R.id.loanAmountGirdi);
        monthlyPayment = (EditText) findViewById(R.id.monthlyPaymentGirdi);
        totalPayment = (EditText) findViewById(R.id.totalPaymentGirdi) ;

        interestRateGirdi.addTextChangedListener(interestRateİzleyici);
        loanAmountGirdi.addTextChangedListener(loanAmountİzleyici);

        Button dugme5years = (Button) findViewById(R.id.button5years);
        Button dugme10years = (Button) findViewById(R.id.button10years);
        Button dugme15years = (Button) findViewById(R.id.button15years);
        Button dugme20years = (Button) findViewById(R.id.button20years);
        Button dugme25years = (Button) findViewById(R.id.button25years);
        Button dugme30years = (Button) findViewById(R.id.button30years);
        dugme5years.setOnClickListener(buton5Tikla);
        dugme10years.setOnClickListener(buton10Tikla);
        dugme15years.setOnClickListener(buton15Tikla);
        dugme20years.setOnClickListener(buton20Tikla);
        dugme25years.setOnClickListener(buton25Tikla);
        dugme30years.setOnClickListener(buton30Tikla);

        monthlyPayment.setEnabled(false);
        totalPayment.setEnabled(false);

    }

    public View.OnClickListener buton5Tikla = new View.OnClickListener() {
        public void onClick(View v){
            double n = 5 *12;//years*month
            double i = interestRate/100/12;
            monthlyPaymentValue = (loanAmount * (i * Math.pow((1+ i),n)))/((Math.pow(1+i,n))-1);
            totalPaymentValue = monthlyPaymentValue * n;
            totalPaymentValue = totalPaymentValue - loanAmount;
            monthlyPayment.setText(String.format("%2f", monthlyPaymentValue));
            totalPayment.setText(String.format("%2f",totalPaymentValue));
        }
    };
    public View.OnClickListener buton10Tikla = new View.OnClickListener() {
        public void onClick(View v){
            double n = 10 *12;//years*months
            double i = interestRate/100/12;
            monthlyPaymentValue = (loanAmount * (i * Math.pow((1+ i),n)))/((Math.pow(1+i,n))-1);
            totalPaymentValue = monthlyPaymentValue * n;
            totalPaymentValue = totalPaymentValue - loanAmount;
            monthlyPayment.setText(String.format("%2f", monthlyPaymentValue));
            totalPayment.setText(String.format("%2f",totalPaymentValue));
        }
    };
    public View.OnClickListener buton15Tikla = new View.OnClickListener() {
        public void onClick(View v){
            double n = 15 *12;//years*months
            double i = interestRate/100/12;
            monthlyPaymentValue = (loanAmount * (i * Math.pow((1+ i),n)))/((Math.pow(1+i,n))-1);
            totalPaymentValue = monthlyPaymentValue * n;
            totalPaymentValue = totalPaymentValue - loanAmount;
            monthlyPayment.setText(String.format("%2f", monthlyPaymentValue));
            totalPayment.setText(String.format("%2f",totalPaymentValue));
        }
    };
    public View.OnClickListener buton20Tikla = new View.OnClickListener() {
        public void onClick(View v){
            double n = 20 *12;//years*months
            double i = interestRate/100/12;
            double monthlyPaymentValue = (loanAmount * (i * Math.pow((1+ i),n)))/((Math.pow(1+i,n))-1);
            double totalPaymentValue = monthlyPaymentValue * n;
            totalPaymentValue = totalPaymentValue - loanAmount;
            monthlyPayment.setText(String.format("%2f", monthlyPaymentValue));
            totalPayment.setText(String.format("%2f",totalPaymentValue));
        }
    };
    public View.OnClickListener buton25Tikla = new View.OnClickListener() {
        public void onClick(View v){
            double n = 25 *12;//years*months
            double i = interestRate/100/12;
            monthlyPaymentValue = (loanAmount * (i * Math.pow((1+ i),n)))/((Math.pow(1+i,n))-1);
            totalPaymentValue = monthlyPaymentValue * n;
            totalPaymentValue = totalPaymentValue - loanAmount;
            monthlyPayment.setText(String.format("%2f", monthlyPaymentValue));
            totalPayment.setText(String.format("%2f",totalPaymentValue));
        }
    };
    public View.OnClickListener buton30Tikla = new View.OnClickListener() {
        public void onClick(View v){
            double n = 30 *12;//years*months
            double i = interestRate/100/12;
            monthlyPaymentValue = (loanAmount * (i * Math.pow((1+ i),n)))/((Math.pow(1+i,n))-1);
            totalPaymentValue = monthlyPaymentValue * n;
            totalPaymentValue = totalPaymentValue - loanAmount;
            monthlyPayment.setText(String.format("%2f", monthlyPaymentValue));
            totalPayment.setText(String.format("%2f",totalPaymentValue));
        }
    };

    private TextWatcher interestRateİzleyici = new TextWatcher() {
        @Override
        public void beforeTextChanged(CharSequence s, int start, int count, int after) {

        }

        @Override
        public void onTextChanged(CharSequence s, int start, int before, int count) {
            if(s.toString().length()>0){
                interestRate = Double.parseDouble(s.toString());

            }

        }

        @Override
        public void afterTextChanged(Editable s) {

        }
    };
    private TextWatcher loanAmountİzleyici = new TextWatcher() {
        @Override
        public void beforeTextChanged(CharSequence s, int start, int count, int after) {

        }

        @Override
        public void onTextChanged(CharSequence s, int start, int before, int count) {
            if(s.toString().length()>0){
                loanAmount = Double.parseDouble(s.toString());

            }
        }

        @Override
        public void afterTextChanged(Editable s) {

        }
    };
}
